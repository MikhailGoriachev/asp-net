﻿using System.ComponentModel.DataAnnotations;

namespace HomeWork.Models.BindingModels;

// Модель привязки для выбора диапазона
public class IntBindingModel
{
    // значение
    [Required(ErrorMessage = "Установите значение!")]
    public int? Value { get; set; }


    // конструктор по умолчанию
    public IntBindingModel()
    {

    }


    // конструктор инициализирующий
    public IntBindingModel(int value)
    {
        Value = value;
    }
}
