﻿namespace HomeWork.Models;


public enum SortStateSeller
{
    // Идентификатор
    IdAsc,
    IdDesc,

    // Фамилия
    SurnameAsc,
    SurnameDesc,

    // Процент комиссионных
    InterestAsc,
    InterestDesc,
}
