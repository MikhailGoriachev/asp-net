﻿namespace UsingTagHelpers2.Models.Queries;

public record Query09Result(string SellerFullName, double AvgSellPrice, int Count);

