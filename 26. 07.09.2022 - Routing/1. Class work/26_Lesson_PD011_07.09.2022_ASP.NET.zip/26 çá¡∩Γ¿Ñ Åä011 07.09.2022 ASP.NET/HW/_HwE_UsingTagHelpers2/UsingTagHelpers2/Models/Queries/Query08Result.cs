﻿namespace UsingTagHelpers2.Models.Queries;

public record Query08Result(string ProductName, double AvgPurhaseprice, int Count);

