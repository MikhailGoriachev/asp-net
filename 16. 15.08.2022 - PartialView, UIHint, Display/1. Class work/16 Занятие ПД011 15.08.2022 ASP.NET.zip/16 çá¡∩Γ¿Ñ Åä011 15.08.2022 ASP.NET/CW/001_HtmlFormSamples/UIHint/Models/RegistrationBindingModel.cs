﻿using System.ComponentModel.DataAnnotations;

namespace UIHint.Models;
public class RegistrationBindingModel
{
    // для типа string генерируется text, атрибут UIHint не нужен
    public string Login { get; set; } = null!;

    // атрибут UIHint задает тип поля ввода - тип генерируемого
    // элемента input  EmailAddress --> <input type="email"... />
    // и явно задавать тип в разметке не надо
    [UIHint("EmailAddress")] public string Email { get; set; } = null!;

    // при указании Password сгенерируется тип password для input
    // Password  -->  <input type="password" ... />
    // совпадение имени свойства со значением атрибута - случайное
    [UIHint("Password")]
    public string Password { get; set; }

    // при указании Password сгенерируется тип password для input
    // Password  -->  <input type="password" ... />
    [UIHint("Password")] public string PasswordConfirm { get; set; } = null!;

    // тип данных int распознается автоматически
    // TODO: а как насчет DateTime, double, float?
    public int Age { get; set; }

    // для типа bool генерируется checkbox, атрибут UIHint не нужен 
    public bool TermsAccepted { get; set; }
}

