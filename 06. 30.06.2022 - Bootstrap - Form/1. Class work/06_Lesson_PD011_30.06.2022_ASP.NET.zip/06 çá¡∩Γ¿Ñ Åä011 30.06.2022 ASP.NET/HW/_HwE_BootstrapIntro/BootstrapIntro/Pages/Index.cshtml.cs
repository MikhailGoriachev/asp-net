using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BootstrapIntro.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        } // OnGet
    }
}
