﻿namespace HomeWork.Models.BindingModels;

public record Query01BindingModel(int MaxPrice, int UnitId);
