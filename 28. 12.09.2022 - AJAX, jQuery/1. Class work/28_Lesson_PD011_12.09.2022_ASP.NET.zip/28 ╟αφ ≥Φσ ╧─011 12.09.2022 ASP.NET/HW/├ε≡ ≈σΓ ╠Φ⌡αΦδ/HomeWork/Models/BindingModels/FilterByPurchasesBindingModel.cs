﻿using System.ComponentModel.DataAnnotations;

namespace HomeWork.Models.BindingModels;

// Класс Модель привязки для фильтрации закупок
public class FilterByPurchasesBindingModel
{
    // закупки
    public List<Purchase>? Items { get; set; }

    // минимальная цена
    [Display(Name = "Минимальная цена")]
    public int? MinPrice { get; set; }

    // максимальная цена
    [Display(Name = "Максимальная цена")]
    public int? MaxPrice { get; set; }

    // id единицы измерения
    [Display(Name = "Единицы измерения")]
    public int UnitId { get; set; }

    // id товара
    [Display(Name = "Товар")]
    public int GoodsId { get; set; }


    #region Конструкторы

    // конструктор по умолчанию
    public FilterByPurchasesBindingModel()
    {

    }


    // конструктор инициализирующий
    public FilterByPurchasesBindingModel(List<Purchase>? items, int? minPrice, int? maxPrice, int unitId, int goodsId)
    {
        Items = items;
        MinPrice = minPrice;
        MaxPrice = maxPrice;
        UnitId = unitId;
        GoodsId = goodsId;
    }

    #endregion
}
