﻿namespace HomeWork.Models.BindingModels;

public record Query03BindingModel(int MaxPrice, int GoodsId);
