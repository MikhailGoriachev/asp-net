﻿namespace Homework.Models.Task1;

// Результат вычисления уравнения
public class ExpressionResult
{
    public double A { get; set; }
    public double B { get; set; }
}