﻿namespace AspNetCoreMvcFirst.Models.Task1;

// для передачи результата в представление
public record Result(double A, double B);