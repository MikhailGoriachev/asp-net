using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BootstrapFileUpload.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet() { } // OnGet
    } // class IndexModel
}
