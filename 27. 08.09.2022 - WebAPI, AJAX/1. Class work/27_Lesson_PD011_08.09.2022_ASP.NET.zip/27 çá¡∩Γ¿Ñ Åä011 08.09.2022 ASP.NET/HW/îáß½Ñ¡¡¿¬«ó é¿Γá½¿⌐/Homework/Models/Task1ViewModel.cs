﻿namespace Homework.Models;

public class Task1ViewModel
{
    public Equation? Equation1 { get; set; } = new();

    public Equation? Equation2 { get; set; } = new();
}