﻿namespace AreaPractice.Models;

// для передачи результата в представление
public record Result(double A, double B);