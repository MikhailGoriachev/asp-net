using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Homework1.Pages
{
    public class BookModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
