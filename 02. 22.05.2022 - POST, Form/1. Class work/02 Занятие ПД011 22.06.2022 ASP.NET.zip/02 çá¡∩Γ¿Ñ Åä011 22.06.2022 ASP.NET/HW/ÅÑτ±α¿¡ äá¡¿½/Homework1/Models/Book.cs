﻿namespace Homework1.Models
{
    public class Book
    {
        public string Title { get; set; } = "Python для детей. Самоучитель по программированию";

        public int YearOfPublishing { get; set; } = 2017;

        public string Image { get; set; } = "images/img1.jpg";  


    }
}
