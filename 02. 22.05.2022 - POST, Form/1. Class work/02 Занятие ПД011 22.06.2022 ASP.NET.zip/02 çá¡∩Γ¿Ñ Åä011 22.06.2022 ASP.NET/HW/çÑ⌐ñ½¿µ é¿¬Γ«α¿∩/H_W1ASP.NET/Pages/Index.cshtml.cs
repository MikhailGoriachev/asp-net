using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace H_W1ASP.NET.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
