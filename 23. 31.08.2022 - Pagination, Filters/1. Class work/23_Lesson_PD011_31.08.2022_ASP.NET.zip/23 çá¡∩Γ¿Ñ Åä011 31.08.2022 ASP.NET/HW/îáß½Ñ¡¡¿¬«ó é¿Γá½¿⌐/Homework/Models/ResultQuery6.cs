﻿namespace Homework.Models;

public record ResultQuery6(string Country, string Purpose, DateTime StartDate, int Duration, int TotalCost);
