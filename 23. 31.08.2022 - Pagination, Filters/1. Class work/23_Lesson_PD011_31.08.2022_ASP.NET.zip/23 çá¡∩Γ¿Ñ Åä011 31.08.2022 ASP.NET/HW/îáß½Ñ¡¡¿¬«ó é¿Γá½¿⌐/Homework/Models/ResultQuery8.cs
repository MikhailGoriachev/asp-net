﻿namespace Homework.Models;

public record ResultQuery8(string Country, double TransferAvg);   
