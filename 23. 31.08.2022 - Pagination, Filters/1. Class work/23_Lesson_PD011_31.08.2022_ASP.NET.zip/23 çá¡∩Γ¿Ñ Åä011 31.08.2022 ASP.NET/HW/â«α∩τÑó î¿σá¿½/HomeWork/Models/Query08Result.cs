﻿namespace HomeWork.Models;

// Класс Результат запроса 8
public record Query08Result(string CountryName, double? AvgDailyCost, int? Count);
