﻿namespace HomeWork.Models.BindingModels;

// Модель привязки для запроса 2
public class Query02BindingModel
{
    // id цели поездки
    public int ObjectiveId { get; set; }

    // максимальная стоимость
    public int MaxPrice { get; set; }
}
