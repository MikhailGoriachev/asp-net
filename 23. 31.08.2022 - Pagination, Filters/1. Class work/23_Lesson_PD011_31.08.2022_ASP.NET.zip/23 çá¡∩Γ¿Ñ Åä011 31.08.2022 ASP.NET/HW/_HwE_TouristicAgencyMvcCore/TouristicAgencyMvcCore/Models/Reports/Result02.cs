﻿namespace TouristicAgencyMvcCore.Models.Reports;

// Тип записи коллекции итогового запроса
public record Result02(string Country, double AvgCost, int Amount);

