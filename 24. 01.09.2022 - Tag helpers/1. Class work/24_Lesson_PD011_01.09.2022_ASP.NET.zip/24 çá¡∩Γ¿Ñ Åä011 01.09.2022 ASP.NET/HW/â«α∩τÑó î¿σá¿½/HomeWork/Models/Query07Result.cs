﻿namespace HomeWork.Models;

// Класс Результат запроса 7
public record Query07Result(Objective Objective, int? MinDailyCost, double? AvgDailyCost, int? MaxDailyCost, int? Count);
