﻿namespace TagHelpersDemo.Models;

// пример сложного типа данных для работы с тег-хелпером
public record Person(int Id, string FullName, int Age);

