using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FileUploadDownloadResultReturn.Pages
{
    public class TestPageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
