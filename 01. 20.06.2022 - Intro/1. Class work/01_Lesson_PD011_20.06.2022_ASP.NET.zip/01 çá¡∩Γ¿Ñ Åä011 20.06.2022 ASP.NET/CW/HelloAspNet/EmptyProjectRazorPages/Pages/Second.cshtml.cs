using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EmptyProjectRazorPages.Pages
{
    public class SecondModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
