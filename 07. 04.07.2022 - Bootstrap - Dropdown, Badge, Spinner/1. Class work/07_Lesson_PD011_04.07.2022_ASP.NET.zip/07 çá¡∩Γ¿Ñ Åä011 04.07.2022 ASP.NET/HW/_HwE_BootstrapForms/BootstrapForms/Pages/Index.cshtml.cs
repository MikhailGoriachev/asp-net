using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BootstrapForms.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        } // OnGet
    }
}
