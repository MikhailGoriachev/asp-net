using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace H_W6ASP_NET.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
