using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HomeWork.Pages;

public class PeriodicalsSelection : PageModel
{
    public void OnGet()
    {
        
    }
}