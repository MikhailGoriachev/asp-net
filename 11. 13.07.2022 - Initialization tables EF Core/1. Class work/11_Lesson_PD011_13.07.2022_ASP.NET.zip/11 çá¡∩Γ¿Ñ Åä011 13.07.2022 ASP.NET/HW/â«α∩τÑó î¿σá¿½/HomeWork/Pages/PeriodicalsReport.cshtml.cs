using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HomeWork.Pages;

public class PeriodicalsReport : PageModel
{
    public void OnGet()
    {
        
    }
}