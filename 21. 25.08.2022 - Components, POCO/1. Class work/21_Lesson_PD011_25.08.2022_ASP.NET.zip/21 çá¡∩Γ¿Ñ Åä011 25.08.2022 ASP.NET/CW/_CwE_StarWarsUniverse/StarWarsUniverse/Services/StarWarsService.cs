﻿namespace StarWarsUniverse.Services;


// сервис для получения данных по API от https://swapi.dev/api/
public class StarWarsService
{
}

