﻿namespace HomeWork.Models;

public class Geo
{
    public string? Lat { get; set; }
    public string? Lng { get; set; }
}
