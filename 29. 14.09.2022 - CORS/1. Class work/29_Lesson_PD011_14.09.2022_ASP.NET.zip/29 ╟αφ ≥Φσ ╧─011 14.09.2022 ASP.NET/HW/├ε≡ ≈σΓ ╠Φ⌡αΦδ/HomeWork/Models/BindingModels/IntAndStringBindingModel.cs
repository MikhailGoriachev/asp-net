﻿using System.ComponentModel.DataAnnotations;

namespace HomeWork.Models.BindingModels;

// Модель привязки для выбора диапазона
public class IntAndStringBindingModel
{
    // числовое значение
    [Required(ErrorMessage = "Установите значение!")]
    public int IntValue { get; set; }

    // строковое значение
    [Required(ErrorMessage = "Установите значение!")]
    public string StringValue { get; set; } = "";


    // конструктор по умолчанию
    public IntAndStringBindingModel()
    {

    }


    // конструктор инициализирующий
    public IntAndStringBindingModel(int intValue, string stringValue)
    {
        IntValue = intValue;
        StringValue = stringValue;
    }
}
