﻿using System.ComponentModel.DataAnnotations;

namespace HomeWork.Models.BindingModels;

// Модель привязки для выбора диапазона
public class RangeBindingModel
{
    // минимальное значение
    [Required(ErrorMessage = "Введите минимальное значение!")]
    [Range(0, int.MaxValue, ErrorMessage = "Минимальное значение должно быть больше 0!")]
    public int Min { get; set; }

    // максимальное значение
    [Required(ErrorMessage = "Введите максимальное значение!")]
    [Range(0, int.MaxValue, ErrorMessage = "Максимальное значение должно быть больше 0!")]
    public int Max { get; set; }

    public RangeBindingModel()
    {

    }
}
