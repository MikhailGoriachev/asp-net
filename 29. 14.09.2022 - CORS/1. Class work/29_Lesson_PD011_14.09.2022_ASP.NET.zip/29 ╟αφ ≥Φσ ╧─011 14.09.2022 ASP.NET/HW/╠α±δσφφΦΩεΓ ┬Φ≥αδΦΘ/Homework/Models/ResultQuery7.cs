﻿namespace Homework.Models;

public record ResultQuery7(string Purpose, int MinPrice, double AvgPrice, int MaxPrice);
