﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations; /* для атрибутов свойств */
using System.Linq;
using System.Threading.Tasks;

namespace DataAnnotations.Model
{
    public class RegistrationBindingModel
    {
        // Использование атрибутов валидации
        // Атрибуты:
        // [CreditCard]
        // [Compare]
        // [EmailAddress]
        // [Phone]
        // [Range]
        // [RegularExpression]
        // [Required]
        // [StringLength]
        // [Url]
        // [Remote]             -- проверка внегним сервисом
        // проблема - по умолчанию выводятся системные сообщения, но есть и решение:
        // можно задать собственные сообщения вместо стандартных - свойство ErrorMessage
        [Required(ErrorMessage = "Обязательно к заполнению")]
        [StringLength(50, ErrorMessage = "Длина имени не более 50 символов")]
        [Display(Name = "Имя")]
        public string FirstName { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 1)]
        [Display(Name = "Фамилия")]
        public string LastName { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Phone(ErrorMessage = "Не является корректным телефонным номером")]
        [Display(Name = "Номер телефона")]
        public string PhoneNumber { get; set; }

        [Required]
        [UIHint("Password")]
        [StringLength(15, MinimumLength = 6)]
        [Compare("ConfirmPassword")]
        [Display(Name = "Пароль")]
        public string Password { get; set; }

        [Required]
        [StringLength(15, MinimumLength = 6)]
        [UIHint("Password")]
        [Display(Name = "Подтверждение пароля")]
        public string ConfirmPassword { get; set; }
    }
}
