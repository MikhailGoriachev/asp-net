﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using HomeWork.Infrastructure;
using Newtonsoft.Json;

namespace HomeWork.Models;

// Класс Клиент
public class ClientPasswordBindingModel
{
    // id
    [UIHint("HiddenInput")] public int Id { get; set; }

    // пароль
    [Required(ErrorMessage = "Введите пароль клиента!")]
    [StringLength(28, MinimumLength = 8, ErrorMessage = "Длина пароля должна быть от 8 до 28 символов!")]
    [Compare("PasswordConfirm", ErrorMessage = "Пароль и подтверждение пароля должны совпадать!")]
    [Display(Name = "Пароль")]
    [UIHint("Password")]
    public string? Password { get; set; }

    // подтверждение пароля
    [Required(ErrorMessage = "Введите подтверждение пароля клиента!")]
    [StringLength(28, MinimumLength = 8, ErrorMessage = "Длина пароля должна быть от 8 до 28 символов!")]
    [UIHint("Password")]
    [Display(Name = "Подтверждение пароля")]
    public string? PasswordConfirm { get; set; }

    #region Конструкторы

    // конструктор по умолчанию
    public ClientPasswordBindingModel()
    {
    }


    // конструктор инициализирующий
    public ClientPasswordBindingModel(Client client)
    {
        Id = client.Id;
        Password = PasswordConfirm = client.Password;
    }

    #endregion
}
