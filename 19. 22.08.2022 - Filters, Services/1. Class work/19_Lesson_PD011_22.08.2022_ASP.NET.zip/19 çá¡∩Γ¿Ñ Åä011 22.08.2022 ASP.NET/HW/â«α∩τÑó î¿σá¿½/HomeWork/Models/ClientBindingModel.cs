﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using HomeWork.Infrastructure;
using Newtonsoft.Json;

namespace HomeWork.Models;

// Класс Клиент
public class ClientBindingModel
{
    // id
    [UIHint("HiddenInput")] public int Id { get; set; }

    // фамилию
    [Display(Name = "Фамилия:")]
    [Required(ErrorMessage = "Введите фамилию клиента!")]
    public string? Surname { get; set; }

    // имя
    [Display(Name = "Имя:")]
    [Required(ErrorMessage = "Введите имя клиента!")]
    public string? Name { get; set; }

    // отчество
    [Display(Name = "Отчество:")]
    [Required(ErrorMessage = "Введите отчество клиента!")]
    public string? Patronymic { get; set; }

    // возраст клиента в годах
    [Display(Name = "Возраст (лет):")]
    [Range(18, 65, ErrorMessage = "Возраст клиента должен быть в диапазоне от 18 до 65 лет")]
    [Required(ErrorMessage = "Введите возраст клиента!")]
    public int YearsOld { get; set; }

    // номер телефона
    [Display(Name = "Номер телефона")]
    [DataType(DataType.PhoneNumber)]
    [Required(ErrorMessage = "Введите номер телефона клиента!")]
    public string? TelNumber { get; set; }

    // адрес электронной почты
    [Required(ErrorMessage = "Введите адрес электронной почты клиента!")]
    [Display(Name = "Эл.почта")]
    [UIHint("EmailAddress")]
    [EmailAddress(ErrorMessage = "Неверный формат электронной почты!")]
    public string? Mail { get; set; }

    // признак постоянного клиента
    [Required(ErrorMessage = "Укажите значение признака постоянного клиента!")]
    [Display(Name = "Постоянный клиент:")]
    [UIHint("Boolean")]
    public bool IsActive { get; set; }

    // фотография пользователя
    [UIHint("HiddenInput")] public string? ImageFile { get; set; }

    [Display(Name = "Фотография клиента:")]
    public IFormFile? FormFile { get; set; }

    #region Конструкторы

    // конструктор по умолчанию
    public ClientBindingModel()
    {
    }


    // конструктор инициализирующий
    public ClientBindingModel(Client client)
    {
        Id = client.Id;
        Surname = client.Surname;
        Name = client.Name;
        Patronymic = client.Patronymic;
        YearsOld = client.YearsOld;
        TelNumber = client.TelNumber;
        Mail = client.Mail;
        IsActive = client.IsActive;
        ImageFile = client.ImageFile;
    }

    #endregion
}
