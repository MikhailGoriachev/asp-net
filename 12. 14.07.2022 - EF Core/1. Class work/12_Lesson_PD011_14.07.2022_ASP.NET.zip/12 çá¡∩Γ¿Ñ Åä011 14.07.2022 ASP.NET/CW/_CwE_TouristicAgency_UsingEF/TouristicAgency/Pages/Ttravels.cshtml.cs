using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TouristicAgency.Pages
{
    public class TtravelsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
