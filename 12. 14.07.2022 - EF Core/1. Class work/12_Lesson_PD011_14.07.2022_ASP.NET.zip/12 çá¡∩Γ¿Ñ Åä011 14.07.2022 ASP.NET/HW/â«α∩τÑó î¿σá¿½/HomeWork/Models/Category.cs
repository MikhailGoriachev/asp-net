﻿namespace HomeWork.Models;

// Класс Категория
public class Category
{
    // идентификатор
    public int Id { get; set; }

    // название категории
    public string? Name { get; set; }
}
