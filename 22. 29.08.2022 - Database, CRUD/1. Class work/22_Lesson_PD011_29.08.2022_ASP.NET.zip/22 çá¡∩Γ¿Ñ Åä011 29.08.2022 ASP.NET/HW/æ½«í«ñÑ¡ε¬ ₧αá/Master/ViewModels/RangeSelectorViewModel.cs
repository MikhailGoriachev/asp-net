﻿namespace Master.ViewModels;


public sealed class RangeSelectorViewModel
{
    public string? Title { get; init; }
    public string? Action { get; init; }
}