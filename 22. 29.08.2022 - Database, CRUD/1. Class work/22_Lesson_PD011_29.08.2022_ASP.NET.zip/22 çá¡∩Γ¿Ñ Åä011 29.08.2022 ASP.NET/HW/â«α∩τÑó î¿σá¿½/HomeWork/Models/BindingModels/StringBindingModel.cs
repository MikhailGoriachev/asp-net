﻿using System.ComponentModel.DataAnnotations;

namespace HomeWork.Models.BindingModels;

// Модель привязки для выбора диапазона
public class StringBindingModel
{
    // минимальное значение
    [Required(ErrorMessage = "Установите значение!")]
    public string? Value { get; set; }

    public StringBindingModel()
    {

    }


    // конструктор инициализирующий
    public StringBindingModel(string? value)
    {
        Value = value;
    }
}
