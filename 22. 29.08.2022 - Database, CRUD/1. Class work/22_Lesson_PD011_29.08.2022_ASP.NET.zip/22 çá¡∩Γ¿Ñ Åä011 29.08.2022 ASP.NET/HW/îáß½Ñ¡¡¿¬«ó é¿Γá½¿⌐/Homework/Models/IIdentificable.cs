﻿namespace Homework.Models;

// Интерфейс предоставляющий доступ к идентификатору
public interface IIdentificable
{
    public int Id { get; set; }
}