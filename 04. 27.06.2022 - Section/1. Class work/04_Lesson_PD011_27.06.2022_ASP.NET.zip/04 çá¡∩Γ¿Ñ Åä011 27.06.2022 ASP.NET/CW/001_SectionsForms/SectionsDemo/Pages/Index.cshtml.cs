using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SectionsDemo.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
