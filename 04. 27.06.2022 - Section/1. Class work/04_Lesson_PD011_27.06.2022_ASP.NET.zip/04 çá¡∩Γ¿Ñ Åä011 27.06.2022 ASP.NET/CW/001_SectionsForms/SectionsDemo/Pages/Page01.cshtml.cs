using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SectionsDemo.Pages
{
    public class Page01Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
