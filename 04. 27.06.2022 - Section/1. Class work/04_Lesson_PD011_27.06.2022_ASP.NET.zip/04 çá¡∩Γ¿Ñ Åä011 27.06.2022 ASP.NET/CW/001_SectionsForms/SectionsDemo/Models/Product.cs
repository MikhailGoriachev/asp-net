﻿namespace SectionsDemo.Models
{
    public record class Product(string Name, int Price, string Company);
}
