﻿namespace SectionsDemo.Models
{
    // мощель для Page04
    public record class Enterprise(int Id, string Name);
}
