using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BindingRouteHandler.Pages
{
    public class Page1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
