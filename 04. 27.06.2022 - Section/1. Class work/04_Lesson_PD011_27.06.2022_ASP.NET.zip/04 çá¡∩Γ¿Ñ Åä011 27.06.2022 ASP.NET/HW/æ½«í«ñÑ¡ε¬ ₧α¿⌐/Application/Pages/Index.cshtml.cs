﻿using Microsoft.AspNetCore.Mvc.RazorPages;


namespace Application.Pages;


public class IndexModel : PageModel
{
    public void OnGet() { }
}