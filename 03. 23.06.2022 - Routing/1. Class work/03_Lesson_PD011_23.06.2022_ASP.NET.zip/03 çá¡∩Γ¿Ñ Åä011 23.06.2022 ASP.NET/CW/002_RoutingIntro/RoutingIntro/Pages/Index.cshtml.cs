using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RoutingIntro.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
