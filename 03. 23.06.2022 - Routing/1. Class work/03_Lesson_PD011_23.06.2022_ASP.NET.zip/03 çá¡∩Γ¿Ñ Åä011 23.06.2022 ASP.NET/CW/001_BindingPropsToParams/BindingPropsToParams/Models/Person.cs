﻿namespace BindingPropsToParams.Models;
public record class Person(string Name, int Age);
