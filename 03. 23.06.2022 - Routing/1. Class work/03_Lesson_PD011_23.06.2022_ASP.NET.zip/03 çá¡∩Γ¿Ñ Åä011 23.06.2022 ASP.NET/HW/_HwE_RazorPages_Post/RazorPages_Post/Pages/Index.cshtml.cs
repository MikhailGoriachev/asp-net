using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorPages_Post.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
