﻿namespace UsingTagHelpers.Models.Queries;

public record Query07Result(string ProductNane, double AvgPurhaseprice, int Count);

