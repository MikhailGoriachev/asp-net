﻿namespace UsingTagHelpers.Models.Queries;

public record Query08Result(string SellerFullName, double AvgSellPrice, int Count);

