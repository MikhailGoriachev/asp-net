﻿using System.ComponentModel.DataAnnotations;
using Home_work.Infrastructure;

namespace Home_work.Models.Clients;

public class ClientBindingModel
{

    public int Id { get; set; } //Id

    public string? PhotoFile { get; set; }

    [Required(ErrorMessage = "Поле обязатено к заполнению!")]
    [Display(Name = "Фамилия клиента")]
    public string Surname { get; set; } //Фамилия 

    [Required(ErrorMessage = "Поле обязатено к заполнению!")]
    [Display(Name = "Имя клиента")]
    public string Name { get; set; } //Имя


    [Required(ErrorMessage = "Поле обязатено к заполнению!")]
    [RegularExpression(@"^[А-ЯA-ZЁ][a-zа-яё ]+", ErrorMessage = "Возмоны только буквы и начало слова с заглавной буквы")]
    [Display(Name = "Отчество клиента")]
    public string Patronymic { get; set; } //Отчество


    [UIHint("Number")]
    [Range(18, 65, ErrorMessage = "Возраст должен быть в диапазоне от 18 до 65 лет")]
    [Required(ErrorMessage = "Поле обязатено к заполнению!")]
    [Display(Name = "Возраст клиента")]
    public int Age { get; set; } //Возраст


    [Required(ErrorMessage = "Поле обязатено к заполнению!")]
    [Phone(ErrorMessage = "Телефон введён некорректно")]
    [Display(Name = "Номер телефона клиента")]
    public string PhoneNumber { get; set; } //Номер телефон

    [UIHint("email")]
    [Required(ErrorMessage = "Поле обязатено к заполнению!")]
    [EmailAddress(ErrorMessage = "E-mail введён некорректно")]
    [Display(Name = "Электронный адрес клиента")]
    public string Email { get; set; } //электронная

    private string _password;


    [UIHint("Password")]
    [Required(ErrorMessage = "Поле обязатено к заполнению!")]
    [StringLength(28, MinimumLength = 8, ErrorMessage = "Длина пароля длжна быть от 8 до 28 символов")]
    [Display(Name = "Пароль")]
    public string Password
    {

        get => _password;
        set => _password = value;

    } //Пароль


    [UIHint("Password")]
    [Required(ErrorMessage = "Поле обязатено к заполнению!")]
    [StringLength(28, MinimumLength = 8, ErrorMessage = "Длина пароля длжна быть от 8 до 28 символов")]
    [Compare("Password", ErrorMessage = "Пароли не совпадают!")]
    [Display(Name = "Подтверждение пароляя")]
    public string PasswordConfirm
    {

        get => _password;
        set => _password = value;

    } //Пароль

    [Display(Name = "Постоянный клиент")]
    public bool IsConstant { get; set; } //Приpнак постоянного клиента

    #region Конструкторы

    public ClientBindingModel(int id, string surname, string name, string patronymic, int age, string phoneNumber, string email, string password, string fileName, bool isConstant)
    {
        Id = id;
        Surname = surname;
        Name = name;
        Patronymic = patronymic;
        Age = age;
        PhoneNumber = phoneNumber;
        Email = email;
        Password = PasswordConfirm =  password;
        PhotoFile = fileName;
        IsConstant = isConstant;
    }


    public ClientBindingModel(Client client)
    {
        Id = client.Id;
        Surname = client.Surname;
        Name = client.Name;
        Patronymic = client.Patronymic;
        Age = client.Age;
        PhoneNumber = client.PhoneNumber;
        Email = client.Email;
        Password = PasswordConfirm = client.Password;
        PhotoFile = client.PhotoFile;
        IsConstant = client.IsConstant;
        EncodePassword();
    }

    public ClientBindingModel() : this(1, "", "", "", 21, "+38 071 123 4567", "", "", "", false)
    {

    }
    #endregion

    //Кодирование/Декодирование пароля
    public void EncodePassword() => _password = Utils.EncodeString(_password);
}
