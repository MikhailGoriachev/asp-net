﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BindingComplexType.Model;

// класс для привязки
//    а) открытые свойства
//    б) конструктор по умолчанию
public class RegistrationBindingModel
{
    // открытые свойства

    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Email { get; set; }
    public string PhoneNumber { get; set; }


    // конструктор по умолчанию
    public RegistrationBindingModel() {
        FirstName = "";
        LastName = "";
        Email = "";
        PhoneNumber = "";
    } // RegistrationBindingModel
}
