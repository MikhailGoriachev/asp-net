﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace SelectBindingSource.Controllers;

public class HomeController : Controller
{
    // GET /Home/Index
    public IActionResult Index() => View();


    [HttpPost]
    /*
     * [FromHeader] – привязка к HTTP заголовкам
     * [FromQuery] – привязка к значению Query String
     * [FromRoute] – привязка к параметру маршрута
     * [FromForm] – привязка к данным формы, отправленным в теле запроса
     * [FromBody] – привязка к контенту тела запроса
     *              Только один параметр метода действия может использовать [FromBody]
     * [BindNever] – пропускать параметр во время привязки модели
     * [BindRequired] – model binder выдаст ошибку если для параметра не будет значения
     * [FromServices] – параметр должен быть предоставлен через внедрение зависимости.
     *
     */
    // Поочередно проверить атрибуты [FromForm] [FromQuery] [FromHeader] 
    public IActionResult Data([FromQuery] string myValue) {
        Debug.WriteLine("myValue = " + myValue);

        return Json(new {Value = myValue});
    } // Data
} // class HomeController 
