﻿namespace BindingCollection.Model;

// только для удобства визуализации
public record RegistrationViewModel(RegistrationBindingModel BindingModel, List<string> Addresses);

